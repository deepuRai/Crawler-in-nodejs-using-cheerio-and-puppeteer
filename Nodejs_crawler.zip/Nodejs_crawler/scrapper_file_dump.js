// reddit-scraper.js

const cheerio = require('cheerio');
const puppeteer = require('puppeteer');
var fs = require('fs');

const url = 'please specify main url';

puppeteer
  .launch({args: ['--no-sandbox']})
  .then(browser => browser.newPage())
  .then(page => {
    return page.goto(url).then(function() {
      return page.content();
    });
  })
  .then(html => {
    const $ = cheerio.load(html);
   
    links = $("body:contains(creative opportunities)").length;
    if(links==1){
        fs.appendFileSync('link.txt', html);
    }

    console.log(links);
  })
  .catch(console.error);
