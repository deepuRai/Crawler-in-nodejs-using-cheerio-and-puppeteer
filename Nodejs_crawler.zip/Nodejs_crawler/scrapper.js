
const puppeteer = require('puppeteer');
var fs = require('fs');
const fileLinksArray = [];
const domainName = "base url without http:// or https://"
async function main() {
  try {
    const browser = await puppeteer.launch({args: ['--no-sandbox']});
    const [page] = await browser.pages();

    await page.goto('main url');

    // way 2
    const elementHandles = await page.$$('a');
    const propertyJsHandles = await Promise.all(
      elementHandles.map(handle => handle.getProperty('href'))
    );
    const hrefs2 = await Promise.all(
      propertyJsHandles.map(handle => handle.jsonValue())
    );

    //console.log('url datas ', hrefs2);

    const stringIsIncluded = await page.evaluate(() => {
      const string = 'creativeopportunities';
      const selector = 'body';
      return document.querySelector(selector).innerText.includes(string);
    });

    console.log('included or not', stringIsIncluded);


    await page.screenshot({path:'example.png'});
  const html = await page.content();
//console.log(html);

    const cdp = await page.target().createCDPSession();
    const { data } = await cdp.send('Page.captureSnapshot', { format: 'mhtml' });
    fs.writeFileSync('page.html', data);

    await browser.close();

    return hrefs2;
  } catch (err) {
    console.error(err);
  }
};

async function getAllSublinks(arrayDataLinks) {
  try {


    //iterate through each link and write it to file 
    for(let link of arrayDataLinks) {
    const browser = await puppeteer.launch({args: ['--no-sandbox']});
    const [page] = await browser.pages();

    await page.goto(link);

    // way 2
    const elementHandles = await page.$$('a');
    const propertyJsHandles = await Promise.all(
      elementHandles.map(handle => handle.getProperty('href'))
    );
    const hrefs2 = await Promise.all(
      propertyJsHandles.map(handle => handle.jsonValue())
    );

    console.log('url datas ', hrefs2);
   
    for(let link of hrefs2) {

      //ignore self page redirection link
      var isContains=link.search('javascript') !== -1;

      //ignore rss feed
      var isContainsfeed=link.search('rss') !== -1;
      //check for undefined
      var isContainsundefinedLink=link.search('undefined') !== -1;
      
      //extract domain name
      var urlParts = link.replace('http://','').replace('https://','').split(/[/?#]/);
      var domain = urlParts[0];
      if(isContains === false && isContainsfeed === false && fileLinksArray.indexOf(link) == -1 && domainName==domain &&isContainsundefinedLink === false) 

    fs.appendFileSync('listOfLinks.txt', '\r\n'+link);
    fileLinksArray.push(link);
    }
    await browser.close();

    }
  } catch (err) {
    console.error(err);
  }


  readDataFromFile()

};


async function readDataFromFile() {
  try {

    var lineReader = require('readline').createInterface({
      input: require('fs').createReadStream('listOfLinks.txt')
    });
    
     lineReader.on('line', async function (line) {
      console.log('Line from file:', line);
   

    //iterate through each link and write it to file 
  
    const browser = await puppeteer.launch({args: ['--no-sandbox']});
    const [page] = await browser.pages();

    await page.goto(line);

    // way 2
    const elementHandles = await page.$$('a');
    const propertyJsHandles = await Promise.all(
      elementHandles.map(handle => handle.getProperty('href'))
    );
    const hrefs2 = await Promise.all(
      propertyJsHandles.map(handle => handle.jsonValue())
    );

    console.log('url datas ', hrefs2);
   
    for(let link of hrefs2) {

      //ignore self page redirection link
      var isContains=link.search('javascript') !== -1;

      //ignore rss feed
      var isContainsfeed=link.search('rss') !== -1;
      //check for undefined
      var isContainsundefinedLink=link.search('undefined') !== -1;
      
      //extract domain name
      var urlParts = link.replace('http://','').replace('https://','').split(/[/?#]/);
      var domain = urlParts[0];
      if(isContains === false && isContainsfeed === false && fileLinksArray.indexOf(link) == -1 && domainName==domain &&isContainsundefinedLink === false) 

    fs.appendFileSync('listOfLinks.txt', '\r\n'+link);
    fileLinksArray.push(link);
    }
    await browser.close();
  });

  
    
  } catch (err) {
    console.error(err);
  }


 
  
};



var arrayDataLinks = main()

getAllSublinks(arrayDataLinks)







